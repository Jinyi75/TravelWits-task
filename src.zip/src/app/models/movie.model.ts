export class Movie {
    title: string;
    rating: number;
    category: string;
}